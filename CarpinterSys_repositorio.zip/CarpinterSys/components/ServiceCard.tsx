import type { Servicio } from "../types";

export function ServiceCard({ service }: { service: Servicio }) {
  return (
    <article className="card">
      <h3>{service.nombre}</h3>
      <p>{service.descripcion}</p>
      {service.precio !== undefined && <strong>Desde ${service.precio.toLocaleString("es-MX")} MXN</strong>}
    </article>
  );
}