import Link from "next/link";

export function Navbar() {
  return (
    <nav>
      <strong>Carpintería Morales</strong>
      <div>
        <Link href="/">Inicio</Link>
        <Link href="/servicios">Servicios</Link>
        <Link href="/cotizacion">Cotización</Link>
        <Link href="/contacto">Contacto</Link>
        <Link href="/admin">Administración</Link>
      </div>
    </nav>
  );
}