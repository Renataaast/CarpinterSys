import Link from "next/link";

const proyectos = [
  { titulo: "Cocina integral", categoria: "Cocinas" },
  { titulo: "Mueble a medida", categoria: "Mobiliario" },
  { titulo: "Proyecto residencial", categoria: "Residencial" }
];

export default function HomePage() {
  return (
    <>
      <section className="hero">
        <div className="container">
          <h1>Carpintería Morales</h1>
          <p>Diseño y fabricación de mobiliario de madera a medida.</p>
          <Link className="btn" href="/cotizacion">Solicitar cotización</Link>
        </div>
      </section>
      <section className="container">
        <h2>Proyectos destacados</h2>
        <div className="grid">
          {proyectos.map((p) => (
            <article className="card" key={p.titulo}>
              <h3>{p.titulo}</h3>
              <p>{p.categoria}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}