"use client";

import { FormEvent, useState } from "react";
import type { Cotizacion } from "../../types";
import { supabase } from "../../lib/supabase";

export default function CotizacionPage() {
  const [mensaje, setMensaje] = useState("");

  async function enviar(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const cotizacion: Cotizacion = {
      nombre: String(data.get("nombre") || ""),
      correo: String(data.get("correo") || ""),
      telefono: String(data.get("telefono") || ""),
      servicio: String(data.get("servicio") || ""),
      descripcion: String(data.get("descripcion") || ""),
      estado: "pendiente"
    };

    if (!supabase) {
      setMensaje("Formulario preparado. Configure las variables de Supabase para guardar la cotización.");
      return;
    }

    const { error } = await supabase.from("cotizaciones").insert(cotizacion);
    setMensaje(error ? "No fue posible guardar la cotización." : "Cotización enviada correctamente.");
    if (!error) e.currentTarget.reset();
  }

  return (
    <section className="container">
      <h1>Solicitar cotización</h1>
      <form className="card" onSubmit={enviar}>
        <label>Nombre<input name="nombre" required /></label>
        <label>Correo<input name="correo" type="email" required /></label>
        <label>Teléfono<input name="telefono" /></label>
        <label>Servicio<select name="servicio" defaultValue="Muebles a medida">
          <option>Muebles a medida</option>
          <option>Cocinas integrales</option>
          <option>Proyecto residencial</option>
        </select></label>
        <label>Descripción<textarea name="descripcion" rows={5} required /></label>
        <button className="btn" type="submit">Enviar solicitud</button>
        {mensaje && <p>{mensaje}</p>}
      </form>
    </section>
  );
}