import { supabase } from "../../lib/supabase";

export default async function AdminPage() {
  let cotizaciones: any[] = [];
  let aviso = "Configura Supabase para consultar las cotizaciones.";

  if (supabase) {
    const result = await supabase
      .from("cotizaciones")
      .select("*")
      .order("created_at", { ascending: false });
    cotizaciones = result.data || [];
    aviso = result.error ? "No fue posible consultar las cotizaciones." : "";
  }

  return (
    <section className="container">
      <h1>Panel de administración</h1>
      <div className="card">
        <h2>Cotizaciones</h2>
        {aviso && <p>{aviso}</p>}
        {cotizaciones.length === 0 ? (
          <p>No hay cotizaciones para mostrar.</p>
        ) : (
          cotizaciones.map((c) => (
            <div key={c.id} style={{borderTop:"1px solid #ddd",padding:"12px 0"}}>
              <strong>{c.nombre}</strong>
              <p>{c.servicio} — {c.estado}</p>
              <small>{c.correo}</small>
            </div>
          ))
        )}
      </div>
    </section>
  );
}