import { ServiceCard } from "../../components/ServiceCard";
import type { Servicio } from "../../types";

const servicios: Servicio[] = [
  { nombre: "Cocinas integrales", descripcion: "Diseño y fabricación de cocinas personalizadas.", precio: 0 },
  { nombre: "Muebles a medida", descripcion: "Mobiliario adaptado a las necesidades del cliente.", precio: 0 },
  { nombre: "Proyectos residenciales", descripcion: "Soluciones de carpintería para espacios residenciales.", precio: 0 }
];

export default function ServiciosPage() {
  return (
    <section className="container">
      <h1>Servicios</h1>
      <div className="grid">
        {servicios.map((service) => <ServiceCard key={service.nombre} service={service} />)}
      </div>
    </section>
  );
}