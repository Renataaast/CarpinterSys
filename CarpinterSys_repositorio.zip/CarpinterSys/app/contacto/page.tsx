export default function ContactoPage() {
  return (
    <section className="container">
      <h1>Contacto</h1>
      <div className="card">
        <p>Para solicitar información o una cotización, utiliza el formulario de contacto y cotización del sistema.</p>
        <p>Carpintería Morales — atención personalizada y proyectos a medida.</p>
      </div>
    </section>
  );
}