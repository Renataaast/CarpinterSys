export type Cotizacion = {
  id?: string;
  nombre: string;
  correo: string;
  telefono?: string;
  servicio: string;
  descripcion: string;
  estado?: "pendiente" | "en_revision" | "atendida";
  created_at?: string;
};

export type Proyecto = {
  id?: string;
  titulo: string;
  descripcion?: string;
  categoria?: string;
  imagen_url?: string;
};

export type Servicio = {
  id?: string;
  nombre: string;
  descripcion: string;
  precio?: number;
};

export type Perfil = {
  id?: string;
  nombre_negocio: string;
  descripcion?: string;
  telefono?: string;
  correo?: string;
  direccion?: string;
};