create table if not exists cotizaciones (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  correo text not null,
  telefono text,
  servicio text not null,
  descripcion text not null,
  estado text default 'pendiente',
  created_at timestamptz default now()
);

create table if not exists servicios (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  descripcion text not null,
  precio numeric
);

create table if not exists proyectos (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descripcion text,
  categoria text,
  imagen_url text
);

create table if not exists perfil (
  id uuid primary key default gen_random_uuid(),
  nombre_negocio text not null,
  descripcion text,
  telefono text,
  correo text,
  direccion text
);